<?php
$conn = mysqli_connect("localhost", "root", "", "biodataku");
if (!$conn) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
?>

